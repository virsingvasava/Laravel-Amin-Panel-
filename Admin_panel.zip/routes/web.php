<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ForgotpasswordController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ProfileController;
use App\Http\Controllers\Admin\UsersController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group(['middleware' => 'guest'], function ($router) {

    Route::get('/admin/login', [LoginController::class, 'index'])->name('login');
    Route::post('/submit', [LoginController::class, 'submit'])->name('login.submit');

    Route::get('/forgot-password', [ForgotpasswordController::class, 'index'])->name('forgot_password');
	Route::post('/forgot-password/submit', [ForgotpasswordController::class, 'submit'])->name('forgot_password.submit');
	
	Route::get('/reset-password/{token}', [ForgotpasswordController::class, 'reset_password'])->name('auth.reset_password');
	Route::post('/password/submit', [ForgotpasswordController::class, 'password_submit'])->name('password.submit');

});

Route::group(['middleware' => 'auth', 'namespace' => 'Admin' , 'prefix' => 'admin'], function ($router) {

    Route::get('/dashboard', [DashboardController::class, 'index'])->name('admin.dashboard');
    Route::get('/logout', [DashboardController::class, 'logout'])->name('admin.logout');

    Route::group(['prefix' => 'profile'], function ($router) {
		Route::get('/', [ProfileController::class, 'profile'])->name('admin.profile.index');
		Route::post('/update', [ProfileController::class, 'profile_update'])->name('admin.profile.update');
	});

	Route::group(['prefix' => 'change-password'], function ($router) {
		Route::get('/', [ProfileController::class, 'change_password'])->name('admin.change_password');
		Route::post('/update', [ProfileController::class, 'change_password_submit'])->name('admin.change_password.update');
	});

	Route::group(['prefix' => 'users'], function(){
		Route::get('/', [UsersController::class, 'index'])->name('admin.users.index');
		Route::get('/create', [UsersController::class, 'create'])->name('admin.users.create');
		Route::post('/store', [UsersController::class, 'store'])->name('admin.users.store');
		Route::post('/delete', [UsersController::class, 'delete'])->name('admin.users.delete');
		Route::get('/edit/{id}', [UsersController::class, 'edit'])->name('admin.users.edit');
		Route::post('/update', [UsersController::class, 'update'])->name('admin.users.update');
	});

});

Auth::routes();
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
