
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item ">
        <a class="nav-link <?php echo e((request()->is('admin/dashboard*')) ? '' : 'collapsed'); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>Components</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="javascript:void(0)">
              <i class="bi bi-circle"></i><span>Cards</span>
            </a>
          </li>
        </ul>
      </li>
      
      <li class="nav-heading">Pages</li>

      <li class="nav-item">
        <a class="nav-link <?php echo e((request()->is('admin/profile*')) ? '' : 'collapsed'); ?>" href="<?php echo e(route('admin.profile.index')); ?>">
          <i class="bi bi-person"></i>
          <span>Profile</span>
        </a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link <?php echo e((request()->is('admin/users*')) ? '' : 'collapsed'); ?>" href="<?php echo e(route('admin.users.index')); ?>">
          <i class="bi bi-card-list"></i>
          <span>Users</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link <?php echo e((request()->is('admin/blank*')) ? '' : 'collapsed'); ?>" href="javascript:void(0)">
          <i class="bi bi-file-earmark"></i>
          <span>Blank</span>
        </a>
      </li>
      <!--
      <li class="nav-item">
        <a class="nav-link collapsed" href="javascript:void(0)">
          <i class="bi bi-question-circle"></i>
          <span>F.A.Q</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="javascript:void(0)">
          <i class="bi bi-envelope"></i>
          <span>Contact</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="javascript:void(0)">
          <i class="bi bi-card-list"></i>
          <span>Register</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="javascript:void(0)">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Login</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="javascript:void(0)">
          <i class="bi bi-dash-circle"></i>
          <span>Error 404</span>
        </a>
      </li>
      -->
    </ul>
  </aside>
<?php /**PATH /opt/lampp/htdocs/laravel7/resources/views/layouts/admin_sidebar.blade.php ENDPATH**/ ?>