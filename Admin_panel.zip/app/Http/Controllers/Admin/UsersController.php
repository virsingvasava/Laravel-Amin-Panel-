<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Models\User;

class UsersController extends Controller
{
    public function index(){
        
        $userArr = User::where('role', '=', TRUE)->get();
        return view('admin.users.index', compact('userArr'));
    }
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function create()
    {
        return view('admin.users.create');
    }

    public function store(Request $request)
    {
        $service_create = new User;
        $service_create->name = strtolower($request->name);
        $service_create->status = (int) $request->status;
        $service_create->save();

        return redirect()->route('admin.users.index')->with('success','Service added successfully');
    }

    public function view($id)
    {
        $service = User::where('id',$id)->first();
        return view('admin.users.view',compact('service'));
    }

    public function edit($id)
    {
        $service = User::where('id',$id)->first();
        return view('admin.users.edit',compact('service'));
    }

    public function update(Request $request)
    {
        $service_update = Service::where('id',$request->id)->first();
        $service_update->name = strtolower($request->name);
        $service_update->status = (int) $request->status;
        $service_update->save();

        return redirect()->route('admin.users.index')->with('success','Service updated successfully');
    }

    public function delete(Request $request)
    {
        $id = $request->id;
        User::where('id',$id)->delete();
        return redirect()->route('admin.users.index')->with('success','Service deleted successfully');
    }
}
