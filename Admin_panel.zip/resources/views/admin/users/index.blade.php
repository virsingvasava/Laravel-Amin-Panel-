@extends('layouts.admin_app')
@section('title', 'Users')
@section('content')
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Users</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="{{route('admin.dashboard')}}">Home</a></li>
          <li class="breadcrumb-item">List of</li>
          <li class="breadcrumb-item active">Users</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-12">
          <div class="card recent-sales overflow-auto">

            <div class="filter" style="display:none">
              <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                <li class="dropdown-header text-start">
                  <h6>Filter</h6>
                </li>

                <li><a class="dropdown-item" href="#">Today</a></li>
                <li><a class="dropdown-item" href="#">This Month</a></li>
                <li><a class="dropdown-item" href="#">This Year</a></li>
              </ul>
            </div>

            <div class="card-body">
              <h5 class="card-title">List of <span>| Users</span></h5>

              <table class="table table-borderless datatable">
                <thead>
                  <tr>
                  

                    <th>Sr. No.</th>
                    <th>City Name</th>
                    <th>Status</th>
                    <th>Action</th>

                  </tr>
                </thead>
                <tbody>
              
                  @if(!empty($userArr) && count($userArr) > 0)
                  @foreach($userArr as $key => $user)
                  <tr>
                      <td>#{{$key+1}}</td>
                      <td>{{ucfirst($user->name)}}</td>
                      <td>
                          @if($user->status == 1)
                          <!-- <span style="color:green;">Active</span> -->
                          <span class="badge bg-success">Active</span>
                          @else
                          <!-- <span style="color:red;">InActive</span> -->
                          <span class="badge bg-warning">Pending</span>
                          @endif
                      </td>
                      <td class="text-center">
                          </a>
                          <a href="{{route('admin.users.edit',$user->id)}}" class="btn icon_loader btn-sm btn-primary"><i class="fa fa-pen">Edit</i>
                          </a>
                          <a href="javascript:void(0)" class="btn btn-sm btn-danger delete_button" data-id="{{$user->id}}"><i class="fa fa-trash">Delete</i>
                          </a>
                      </td>
                  </tr>
                  @endforeach
              @else
              <tr>
                  <td colspan="10">No Users Found.</td>
              </tr>
              @endif

                </tbody>
              </table>

            </div>

          </div>
        </div>
      </div>
    </section>
  </main>
@endsection
